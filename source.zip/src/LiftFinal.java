import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class LiftFinal {
	public static void main(String[] args)
	{
		System.out.println("Enter number of people");
		Scanner sc=new Scanner(System.in);
		int numUser=sc.nextInt();
		int temp;
		System.out.println("Enter current floor");
		int curFloor=sc.nextInt();
		List<Integer> floorSelection = new ArrayList<Integer>();
		for (int i=0;i<numUser;i++)
		{
			System.out.println("Enter the choice of floor for "+(i+1)+"th person");
			temp=sc.nextInt();
			if(temp>5 || temp<1)
			{
				System.out.println("Invalid floor!! Please enter again");
				i--;
				continue;
			}
			floorSelection.add(temp);
		}

		//creating two lists for two lifts A and B
		List<Integer> A=new ArrayList<Integer>();
		List<Integer> B=new ArrayList<Integer>();
		//Divide the list based on floor number
		for (int i=0;i<numUser;i++)		
		{
			int q = floorSelection.get(i);
			if (q>curFloor)
				A.add(q);
			else
				B.add(q);
		}
		int aCap=A.size();
		int bCap=B.size();
		//if lift is not balanced
		if(aCap!=bCap) 				
		{
			//if lift A has more people
			if(aCap>bCap)
			{
				//Sort A
				Collections.sort(A);
				//Filter people to send over to lift B
				if((Math.abs(curFloor-A.get(0))>Math.abs(curFloor-A.get(aCap-1))))
					Collections.reverse(A);
				//Balance the lifts
				for(int j=0;j<(((int)numUser/2)-bCap);j++)
				{
					B.add(A.remove(0));
				}
				//sort the lists
				Collections.sort(A);
				Collections.sort(B);
			}
			//if lift B has more people
			else
			{
				//sort B
				Collections.sort(B);
				//Filter people to send over to lift A
				if((Math.abs(curFloor-B.get(0))>Math.abs(curFloor-B.get(bCap-1))))
					Collections.reverse(B);		
				//Balance the lifts
				for(int j=0;j<((numUser/2)-aCap);j++)
				{
					A.add(B.remove(0));
				}
				//sort the lists
				Collections.sort(A);
				Collections.sort(B);
			}
		}
		//if lists are balanced
		else
		{
			//sort the lists
			Collections.sort(A);
			Collections.sort(B);			
		}
		aCap=A.size();
		bCap=B.size();
		//To maintain the order of lift
		if((Math.abs(curFloor-A.get(0))>Math.abs(curFloor-A.get(aCap-1))))
			Collections.reverse(A);
		if((Math.abs(curFloor-B.get(0))>Math.abs(curFloor-B.get(bCap-1))))
			Collections.reverse(B);		

		//Lists to store people in lift
		List<Integer> finalA = new ArrayList<Integer>();
		List<Integer> finalB = new ArrayList<Integer>();

		//flag array to avoid ambiguity
		int[] flag = new int[numUser];
		for(int i=0;i<numUser;i++)
			flag[i]=0;
		//Store people id in lift A
		for(int i=0;i<aCap;i++)
		{
			for(int j=0;j<numUser;j++)
			{
				if(flag[j]==0 && A.get(i)==floorSelection.get(j))
				{
					finalA.add(j+1);
					flag[j]=1;
					break;
				}
			}
		}
		//Store people id in lift B
		for(int i=0;i<bCap;i++)
		{
			for(int j=0;j<numUser;j++)
			{
				if(flag[j]==0 && B.get(i)==floorSelection.get(j))
				{
					finalB.add(j+1);
					flag[j]=1;
					break;
				}
			}
		}

		Set<Integer> floorA = new LinkedHashSet<Integer>();
		floorA.addAll(A);
		Set<Integer> floorB = new LinkedHashSet<Integer>();
		floorB.addAll(B);
		System.out.println("Order of floors for Lift A :\n" + floorA);
		System.out.println("Order of floors for Lift B :\n" + floorB);

		System.out.println("Ordered List of people exiting Lift A :\n" + finalA);
		System.out.println("Ordered List of people exiting Lift B :\n" + finalB);

	}

}
