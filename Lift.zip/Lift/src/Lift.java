import java.util.Scanner;
public class Lift 
{
	public static void main(String[] args)
	{
		int numUsers;
		int curFloor;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of users: ");
		numUsers = sc.nextInt();
		System.out.println("Enter current floor number: ");
		curFloor = sc.nextInt();
		int arrUser[] = new int[numUsers];
		boolean upDown[] = new boolean[numUsers];
		int A[][];
		int B[][];
		int upCount=0,downCount=0;
		for(int i=0;i<numUsers;i++)
		{
			System.out.println("For "+(i+1)+"th user:");
			System.out.println("1) Up\n2) Down");
			int j = sc.nextInt();
			upDown[i] = (j==1)?true:false;
			if(j==1)upCount++;
			else downCount++;
			System.out.println("Floor Number");
			arrUser[i] = sc.nextInt();
		}
		for(int i=0;i<numUsers;i++)
		{
			System.out.println(i+" "+upDown[i]+" "+arrUser[i]);
		}
		if(upCount==downCount)
		{
			A = new int[numUsers/2][2];
			B = new int[numUsers-numUsers/2][2];
			int j=0,k=0;
			for(int i=0;i<numUsers;i++)
			{
				if(upDown[i])
				{
					A[j][0]=i;A[j][1]=Math.abs(arrUser[i]-curFloor);
					j++;
				}
				else
				{
					B[k][0]=i;B[k][1]=Math.abs(arrUser[i]-curFloor);k++;
				}
			}
			
			for(int i=0;i<j-1;i++)
			{
				for(int l=i+1;l<j;l++)
				{
					if(A[i][1]>A[l][1])
					{
						int temp[][] = new int[1][2];
						temp[0][0]=A[i][0];temp[0][1]=A[i][1];
						A[i][0]=A[l][0];A[i][1]=A[l][1];
						A[l][0]=temp[0][0];A[l][1]=temp[0][1];
					}
				}
			}
			
			for(int i=0;i<k-1;i++)
			{
				for(int l=i+1;l<k;l++)
				{
					if(B[i][1]>B[l][1])
					{
						int temp[][] = new int[1][2];
						temp[0][0]=B[i][0];temp[0][1]=B[i][1];
						B[i][0]=B[l][0];B[i][1]=B[l][1];
						B[l][0]=temp[0][0];B[l][1]=temp[0][1];
					}
				}
			}
			System.out.println("A");
			for(int i=0;i<j;i++)
			{
				System.out.println(A[i][0]+" "+A[i][1]);
			}
			System.out.println("B");
			for(int i=0;i<k;i++)
			{
				System.out.println(B[i][0]+" "+B[i][1]);
			}
			
		}
		else if(upCount>downCount)
		{
		/*
			for(int i=0;i<numUsers;i++)
			{
				arrUser[i]=Math.abs(arrUser[i]-curFloor);
			}
		*/
			System.out.println("ArrUser Output: ");
			for(int i=0;i<numUsers;i++)
			{
				System.out.println(arrUser[i]);
			}
			A = new int[upCount][2];
			B = new int[numUsers-numUsers/2][2];
			int j=0,k=0;
			for(int i=0;i<numUsers;i++)
			{
				if(upDown[i])
				{
					A[j][0]=i;A[j][1]=Math.abs(arrUser[i]-curFloor);
					j++;
				}
				else
				{
					B[k][0]=i;B[k][1]=Math.abs(arrUser[i]-curFloor);k++;
				}
			}
			System.out.println("A Output: ");
			for(int i=0;i<j;i++)
			{
				System.out.println(A[i][0]+" "+A[i][1]);
			}
			
			System.out.println("B Output: ");
			for(int i=0;i<k;i++)
			{
				System.out.println(B[i][0]+" "+B[i][1]);
			}
			for(int i=0;i<j-1;i++)
			{
				for(int l=i+1;l<j;l++)
				{
					if(A[i][1]>A[l][1])
					{
						int temp[][] = new int[1][2];
						temp[0][0]=A[i][0];temp[0][1]=A[i][1];
						A[i][0]=A[l][0];A[i][1]=A[l][1];
						A[l][0]=temp[0][0];A[l][1]=temp[0][1];
					}
				}
			}
			
			System.out.println("A Sorted Output: ");
			for(int i=0;i<j;i++)
			{
				System.out.println(A[i][0]+" "+A[i][1]);
			}
			int C[][] = new int[numUsers][2];
			int m=0;
			for(int i=0;i<j;i++)
			{
				B[k][0]=A[i][0];
				B[k][1]=-A[i][1];
				k++;
				upCount--;
				downCount++;
				if(upCount==downCount)
				{
					for(int n=i+1;n<j;n++)
					{
						C[m][0] = A[n][0];
						C[m][1] = A[n][1];
						m++;
					}
					break;
				}
			}
			System.out.println("B Output: ");
			for(int i=0;i<k;i++)
			{
				System.out.println(B[i][0]+" "+B[i][1]);
			}
			for(int i=0;i<k-1;i++)
			{
				for(int l=i+1;l<k;l++)
				{
					if(B[i][1]>B[l][1])
					{
						int temp[][] = new int[1][2];
						temp[0][0]=B[i][0];temp[0][1]=B[i][1];
						B[i][0]=B[l][0];B[i][1]=B[l][1];
						B[l][0]=temp[0][0];B[l][1]=temp[0][1];
					}
				}
			}
			System.out.println("B Sorted Output: ");
			for(int i=0;i<k;i++)
			{
				System.out.println(B[i][0]+" "+B[i][1]);
			}
			System.out.println("C");
			for(int i=0;i<m;i++)
			{
				System.out.println(C[i][0]+" "+C[i][1]);
			}
			System.out.println("B");
			int negCnt=0,posCnt=0;
			int pstPos=0;
			for(int i=0;i<k;i++)
			{
				if(B[i][1]<0)negCnt++;
				else
				{
					posCnt++;
					if(pstPos==0)pstPos=i;
				}
				//System.out.println(B[i][0]+" "+B[i][1]);
			}
			if(Math.abs(B[pstPos][1])==Math.abs(B[pstPos-1][1]))
			{
				if(negCnt>posCnt)
				{
					for(int i=pstPos-1;i>=0;i--)
					{
						System.out.println(B[i][0]+" "+B[i][1]);
					}
					for(int i=pstPos;i<k;i++)
					{
						System.out.println(B[i][0]+" "+B[i][1]);
					}
				}
				else
				{
					for(int i=pstPos;i<k;i++)
					{
						System.out.println(B[i][0]+" "+B[i][1]);
					}
					for(int i=pstPos-1;i>=0;i--)
					{
						System.out.println(B[i][0]+" "+B[i][1]);
					}
					
				}
				
			}
			else if(Math.abs(B[pstPos][1])<Math.abs(B[pstPos-1][1]))
			{
				for(int i=pstPos;i<k;i++)
				{
					System.out.println(B[i][0]+" "+B[i][1]);
				}
				for(int i=pstPos-1;i>=0;i--)
				{
					System.out.println(B[i][0]+" "+B[i][1]);
				}
			}
			else
			{
				for(int i=pstPos-1;i>=0;i--)
				{
					System.out.println(B[i][0]+" "+B[i][1]);
				}
				for(int i=pstPos;i<k;i++)
				{
					System.out.println(B[i][0]+" "+B[i][1]);
				}
			}
		}
		else
		{
			/*
			for(int i=0;i<numUsers;i++)
			{
				arrUser[i]=Math.abs(arrUser[i]-curFloor);
			}
			*/
			A = new int[numUsers/2][2];
			B = new int[downCount][2];
			int j=0,k=0;
			for(int i=0;i<numUsers;i++)
			{
				if(upDown[i])
				{
					A[j][0]=i;A[j][1]=Math.abs(arrUser[i]-curFloor);
					j++;
				}
				if(!upDown[i])
				{
					B[k][0]=i;B[k][1]=Math.abs(arrUser[i]-curFloor);k++;
				}
			}
			for(int i=0;i<k-1;i++)
			{
				for(int l=i+1;l<k;l++)
				{
					if(B[i][1]>B[l][1])
					{
						int temp[][] = new int[1][2];
						temp[0][0]=B[i][0];temp[0][1]=B[i][1];
						B[i][0]=B[l][0];B[i][1]=B[l][1];
						B[l][0]=temp[0][0];B[l][1]=temp[0][1];
					}
				}
			}
			int C[][] = new int[numUsers][2];
			int m=0;
			for(int i=0;i<k;i++)
			{
				A[j][0]=B[i][0];
				A[j][1]=-B[i][1];
				j++;
				upCount++;
				downCount--;
				if(upCount==downCount)
				{
					for(int n=i+1;n<k;n++)
					{
						C[m][0] = B[n][0];
						C[m][1] = B[n][1];
						m++;
					}
					break;
				}
			}
			for(int i=0;i<j-1;i++)
			{
				for(int l=i+1;l<j;l++)
				{
					if(A[i][1]>A[l][1])
					{
						int temp[][] = new int[1][2];
						temp[0][0]=A[i][0];temp[0][1]=A[i][1];
						A[i][0]=A[l][0];A[i][1]=A[l][1];
						A[l][0]=temp[0][0];A[l][1]=temp[0][1];
					}
				}
			}
			System.out.println("C");
			for(int i=0;i<m;i++)
			{
				System.out.println(C[i][0]+" "+C[i][1]);
			}
			System.out.println("A");
			int negCnt=0,posCnt=0;
			int pstPos=0;
			for(int i=0;i<j;i++)
			{
				if(A[i][1]<0)negCnt++;
				else
				{
					posCnt++;
					if(pstPos==0)pstPos=i;
				}
				//System.out.println(B[i][0]+" "+B[i][1]);
			}
			if(Math.abs(A[pstPos][1])==Math.abs(A[pstPos-1][1]))
			{
				if(negCnt>posCnt)
				{
					for(int i=pstPos-1;i>=0;i--)
					{
						System.out.println(A[i][0]+" "+A[i][1]);
					}
					for(int i=pstPos;i<j;i++)
					{
						System.out.println(A[i][0]+" "+A[i][1]);
					}
				}
				else
				{
					for(int i=pstPos;i<j;i++)
					{
						System.out.println(A[i][0]+" "+A[i][1]);
					}
					for(int i=pstPos-1;i>=0;i--)
					{
						System.out.println(A[i][0]+" "+A[i][1]);
					}
					
				}
				
			}
			else if(Math.abs(A[pstPos][1])<Math.abs(A[pstPos-1][1]))
			{
				for(int i=pstPos;i<j;i++)
				{
					System.out.println(A[i][0]+" "+A[i][1]);
				}
				for(int i=pstPos-1;i>=0;i--)
				{
					System.out.println(A[i][0]+" "+A[i][1]);
				}
			}
			else
			{
				for(int i=pstPos-1;i>=0;i--)
				{
					System.out.println(A[i][0]+" "+A[i][1]);
				}
				for(int i=pstPos;i<j;i++)
				{
					System.out.println(A[i][0]+" "+A[i][1]);
				}
			}
		}
	}
}
