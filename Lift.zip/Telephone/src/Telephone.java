import java.util.*;
interface directory
{
	
	public default String getNumber()
	{
		Hashtable<String, String> dir= new Hashtable<String, String>();
		dir.put("A", "9090909090");
		dir.put("B", "9090909091");
		dir.put("C", "9090909092");
		dir.put("D", "9090909093");
		String res=null;
		System.out.println("Select a number from following list: ");
		System.out.println(dir);
		Scanner sc1 = new Scanner(System.in);
		res = sc1.next();
		
		return res;
	}
}
class user
{
	String name,number;
	user(String name,String number)
	{
		this.name=name;
		this.number=number;
	}
	Hashtable<String, Integer> history= new Hashtable<String, Integer>();
	public void showInfo()
	{
		System.out.println(this.name+"\t"+this.number+"\n"+this.history);
	}
	public void UpdateHistory(String keypad)
	{
		if(!history.containsKey(keypad))
			history.put(keypad, 1);
		else
			{
				int val = history.get(keypad);
				history.put(keypad, val+1);
			}
		System.out.println("Number\tCalledTimes");
		System.out.println(this.history);
	}
	public void CheckHistory()
	{
		System.out.println("Number\tCalledTimes");
		System.out.println(this.history);
	}
}
public class Telephone extends user implements directory
{
	String keypad;
	Telephone(String name, String number)
	{
		super(name,number);
	}
	public void call()
	{
		int choice;
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Menu:\n1) Dial\n2) Select from history\n3) Select from Directory");
		choice = sc1.nextInt();
		switch(choice)
		{
		case 1:
			keypad=null;
			keypad = sc1.next();
			this.UpdateHistory(keypad);
			break;
		case 2:
			keypad=null;
			//keypad = this.getNumber();
			System.out.println("Select a number from following list: ");
			super.CheckHistory();
			keypad = sc1.next();
			this.UpdateHistory(keypad);
			break;
		case 3:
			keypad = this.getNumber().toString();
			this.UpdateHistory(keypad);
			break;
		}
	}
	public void CheckHistory()
	{
		super.CheckHistory();
	}
	
	public static void main(String[] args)
	{
		
		int choice=0;
		Scanner sc = new Scanner(System.in);
		String name,number;
		System.out.println("Enter UserName");
		name = sc.next();
		System.out.println("Enter UserNUmber");
		number = sc.next();
		Telephone t = new Telephone(name,number);
		while(choice!=3)
		{
			System.out.println("Menu:\n1) Call\n2) Check Call History\n3) Exit");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				t.call();
				break;
			case 2:
				t.CheckHistory();
				break;
			case 3:
				
				break;
			}
		}
	}
}
